import { useState, useEffect } from 'react';
import { Bell, Trash2, CheckCheck, X, Home, Megaphone, Star, Settings, ChevronRight } from 'lucide-react';

interface Notif {
  id: string;
  title: string;
  body: string;
  type: 'property' | 'ad' | 'welcome' | 'admin' | 'general';
  createdAt: string;
  isRead: boolean;
}

interface Props { onBack: () => void; }

const STORAGE_KEY = 'royal_notifications_v2';

const TYPE_META: Record<Notif['type'], { icon: typeof Bell; color: string; bg: string; emoji: string }> = {
  property: { icon: Home,      color: '#00BFA5', bg: 'rgba(0,191,165,0.1)',    emoji: '🏡' },
  ad:       { icon: Megaphone, color: '#f59e0b', bg: 'rgba(245,158,11,0.1)',   emoji: '📢' },
  welcome:  { icon: Star,      color: '#6366f1', bg: 'rgba(99,102,241,0.1)',   emoji: '👋' },
  admin:    { icon: Settings,  color: '#f43f5e', bg: 'rgba(244,63,94,0.1)',    emoji: '⚙️' },
  general:  { icon: Bell,      color: '#00897B', bg: 'rgba(0,137,123,0.1)',    emoji: '🔔' },
};

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1)  return 'الآن';
  if (m < 60) return `منذ ${m} دقيقة`;
  const h = Math.floor(m / 60);
  if (h < 24) return `منذ ${h} ساعة`;
  const d = Math.floor(h / 24);
  if (d < 7)  return `منذ ${d} يوم`;
  return `منذ ${Math.floor(d / 7)} أسبوع`;
}

function loadNotifs(): Notif[] {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); }
  catch { return []; }
}
function saveNotifs(list: Notif[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

// ── Exported helper so other components can push notifications ──
export function pushNotif(n: Omit<Notif, 'id' | 'createdAt' | 'isRead'>) {
  const list = loadNotifs();
  list.unshift({ ...n, id: `${Date.now()}`, createdAt: new Date().toISOString(), isRead: false });
  if (list.length > 50) list.pop();
  saveNotifs(list);
}

export function unreadCount(): number {
  return loadNotifs().filter(n => !n.isRead).length;
}

export default function NotificationsPage({ onBack }: Props) {
  const [list, setList] = useState<Notif[]>([]);

  useEffect(() => {
    const data = loadNotifs();
    // seed demo notifications if empty
    if (data.length === 0) {
      const demos: Notif[] = [
         { id: '1', title: '🛍️ منتج جديد', body: 'سماعات لاسلكية عصرية — توصيل سريع وعرض خاص', type: 'property', createdAt: new Date(Date.now() - 5 * 60000).toISOString(), isRead: false },
         { id: '2', title: '📢 عرض خاص', body: 'خصم 15% على منتجات متجر النخبة حتى نهاية الأسبوع', type: 'ad', createdAt: new Date(Date.now() - 2 * 3600000).toISOString(), isRead: false },
         { id: '3', title: '👋 مرحباً بك!', body: 'أهلاً بك في رويال ستور — اكتشف منتجاتك المفضلة الآن', type: 'welcome', createdAt: new Date(Date.now() - 24 * 3600000).toISOString(), isRead: true },
         { id: '4', title: '🛍️ سعر مخفّض', body: 'حقيبة جلدية مميزة — تخفيض السعر لفترة محدودة', type: 'property', createdAt: new Date(Date.now() - 2 * 86400000).toISOString(), isRead: true },
      ];
      saveNotifs(demos);
      setList(demos);
    } else {
      setList(data);
    }
  }, []);

  const unread = list.filter(n => !n.isRead).length;

  const markAllRead = () => {
    const updated = list.map(n => ({ ...n, isRead: true }));
    setList(updated); saveNotifs(updated);
  };

  const remove = (id: string) => {
    const updated = list.filter(n => n.id !== id);
    setList(updated); saveNotifs(updated);
  };

  const markRead = (id: string) => {
    const updated = list.map(n => n.id === id ? { ...n, isRead: true } : n);
    setList(updated); saveNotifs(updated);
  };

  const clearAll = () => {
    setList([]); saveNotifs([]);
  };

  return (
    <div className="page-enter min-h-screen pb-28">

      {/* ── Hero ─────────────────────────────────────────── */}
      <div className="hero-gradient text-white px-5 pt-16 pb-14 relative overflow-hidden">
        <div className="absolute -bottom-10 -right-10 w-48 h-48 rounded-full bg-white/5 pointer-events-none" />

        <button onClick={onBack} className="flex items-center gap-1.5 text-white/80 mb-5 text-sm font-semibold w-fit">
          <ChevronRight size={18} /> رجوع
        </button>

        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {list.length > 0 && (
              <>
                <button onClick={clearAll} className="px-3 py-1.5 rounded-xl bg-white/15 text-white/80 text-xs font-bold border border-white/20 flex items-center gap-1.5">
                  <Trash2 size={12} /> مسح الكل
                </button>
                {unread > 0 && (
                  <button onClick={markAllRead} className="px-3 py-1.5 rounded-xl bg-white/15 text-white/80 text-xs font-bold border border-white/20 flex items-center gap-1.5">
                    <CheckCheck size={12} /> قراءة الكل
                  </button>
                )}
              </>
            )}
          </div>
          <div className="text-right">
             <h1 className="text-2xl font-black">الدردشة والتواصل</h1>
             <p className="text-white/70 text-sm">{unread > 0 ? `${unread} رسالة وتحديث غير مقروء` : 'كل الرسائل والتحديثات مقروءة'}</p>
          </div>
        </div>

        {/* Summary chips */}
        <div className="relative z-10 flex gap-2 mt-4">
          <div className="px-3 py-1.5 rounded-full bg-white/15 border border-white/20 flex items-center gap-1.5">
            <Bell size={11} className="text-white/70" />
             <span className="text-white/80 text-xs font-bold">{list.length} تحديث</span>
          </div>
          {unread > 0 && (
            <div className="px-3 py-1.5 rounded-full bg-red-400/20 border border-red-300/20 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-400 inline-block" />
              <span className="text-red-200 text-xs font-bold">{unread} جديد</span>
            </div>
          )}
        </div>
      </div>

      {/* ── List ─────────────────────────────────────────── */}
      <div className="px-4 -mt-5 space-y-3">
        {list.length === 0 ? (
          <div className="card-glass rounded-3xl p-12 text-center shadow-sm mt-4">
            <Bell size={52} className="text-[#B2DFDB] mx-auto mb-4" />
            <p className="text-[#0D2926] font-black text-base mb-1">لا توجد إشعارات</p>
             <p className="text-[#90AFAC] text-sm">ستظهر هنا رسائل المتاجر والعروض الجديدة</p>
          </div>
        ) : (
          list.map(n => {
            const meta = TYPE_META[n.type];
            const Icon = meta.icon;
            return (
              <div
                key={n.id}
                onClick={() => markRead(n.id)}
                className={`card-glass rounded-3xl p-4 shadow-sm cursor-pointer transition-all active:scale-[0.98]
                  ${!n.isRead ? 'border-l-2' : 'opacity-90'}`}
                style={!n.isRead ? { borderLeftColor: meta.color } : {}}
              >
                <div className="flex items-start gap-3">
                  {/* Delete btn */}
                  <button
                    onClick={e => { e.stopPropagation(); remove(n.id); }}
                    className="mt-0.5 w-7 h-7 rounded-xl bg-red-50 flex items-center justify-center flex-none hover:bg-red-100 transition-colors"
                  >
                    <X size={13} className="text-red-400" />
                  </button>

                  {/* Content */}
                  <div className="flex-1 text-right">
                    <div className="flex items-center justify-end gap-2 mb-1">
                      {!n.isRead && <span className="w-2 h-2 rounded-full flex-none" style={{ background: meta.color }} />}
                      <p className={`text-sm leading-snug ${n.isRead ? 'font-semibold text-[#4A7B76]' : 'font-black text-[#0D2926]'}`}>
                        {n.title}
                      </p>
                    </div>
                    <p className="text-[#4A7B76] text-xs leading-5">{n.body}</p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="px-2 py-0.5 rounded-lg text-[10px] font-bold" style={{ background: meta.bg, color: meta.color }}>
                        {meta.emoji}
                      </div>
                      <span className="text-[#90AFAC] text-[10px]">{timeAgo(n.createdAt)}</span>
                    </div>
                  </div>

                  {/* Icon */}
                  <div className="w-10 h-10 rounded-2xl flex items-center justify-center flex-none" style={{ background: meta.bg }}>
                    <Icon size={19} style={{ color: meta.color }} />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
