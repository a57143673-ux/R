import { useState } from 'react';
import { Mail, Lock, User, LogIn, Eye, EyeOff, ChevronRight } from 'lucide-react';
import { useGoogleLogin } from '@react-oauth/google';

interface Props {
  onLogin: (name: string, isAdmin: boolean) => void;
  onBack: () => void;
}

type Mode = 'login' | 'register';

// Google icon SVG (official colors)
const GoogleIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
  </svg>
);

export default function LoginPage({ onLogin, onBack }: Props) {
  const [mode, setMode]         = useState<Mode>('login');
  const [username, setUsername] = useState('');
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm]   = useState('');
  const [showPw, setShowPw]     = useState(false);
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);

  const reset = () => { setError(''); setUsername(''); setEmail(''); setPassword(''); setConfirm(''); };

  /* ── Google OAuth ─────────────────────────────────────── */
  const loginWithGoogle = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      try {
        setLoading(true);
        // Fetch user info from Google
        const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
          headers: { Authorization: `Bearer ${tokenResponse.access_token}` },
        });
        const info = await res.json();
        const displayName = info.given_name || info.name || info.email?.split('@')[0] || 'مستخدم';
        onLogin(displayName, false);
      } catch {
        setError('فشل تسجيل الدخول بـ Google — حاول مرة أخرى');
      } finally {
        setLoading(false);
      }
    },
    onError: () => {
      setError('تعذّر الاتصال بـ Google — تأكد من الاتصال بالإنترنت');
    },
  });

  /* ── Email/password submit ────────────────────────────── */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (mode === 'login') {
      if (!email.trim() || !password)   { setError('يرجى إدخال البريد الإلكتروني وكلمة المرور'); return; }
      if (!email.includes('@'))         { setError('البريد الإلكتروني غير صحيح'); return; }
      if (password.length < 6)          { setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل'); return; }
    } else {
      if (!username.trim())             { setError('يرجى إدخال اسم المستخدم'); return; }
      if (!email.includes('@'))         { setError('البريد الإلكتروني غير صحيح'); return; }
      if (password.length < 6)          { setError('كلمة المرور 6 أحرف على الأقل'); return; }
      if (password !== confirm)         { setError('كلمتا المرور غير متطابقتين'); return; }
    }

    setLoading(true);
    await new Promise(r => setTimeout(r, 800));
    setLoading(false);

    const isAdmin = email.toLowerCase().includes('admin');
    onLogin(username || email.split('@')[0], isAdmin);
  };

  return (
    <div className="min-h-screen page-enter">
      {/* ── Hero bg ─────────────────────────────────────── */}
      <div className="hero-gradient relative overflow-hidden px-5 pt-14 pb-32">
        <div className="absolute -top-12 -right-12 w-52 h-52 rounded-full bg-white/5 pointer-events-none" />
        <div className="absolute -bottom-16 -left-10 w-64 h-64 rounded-full bg-white/5 pointer-events-none" />

        <button onClick={onBack} className="flex items-center gap-1.5 text-white/80 mb-8 text-sm font-semibold w-fit relative z-10">
          <ChevronRight size={18} /> رجوع
        </button>

        <div className="text-center relative z-10">
          <div className="w-20 h-20 bg-white/15 border-2 border-white/25 rounded-3xl flex items-center justify-center mx-auto mb-4 text-4xl shadow-xl backdrop-blur-sm">
            🏛
          </div>
          <h1 className="text-3xl font-black text-white">رويال ستور</h1>
          <p className="text-white/70 mt-1.5 text-sm">منصتك لاكتشاف المنتجات والمتاجر المميزة</p>
        </div>
      </div>

      {/* ── Card ────────────────────────────────────────── */}
      <div className="px-4 -mt-24 relative z-10 pb-10">
        <div className="card-glass rounded-3xl p-6 shadow-2xl border border-white/40">

          {/* ── Google login ─────────────────────────────── */}
          <button
            type="button"
            onClick={() => loginWithGoogle()}
            disabled={loading}
            className="w-full py-3.5 bg-white border border-gray-200 text-[#0D2926] font-bold rounded-2xl flex items-center justify-center gap-3 shadow-sm hover:bg-gray-50 active:scale-[0.98] transition-all mb-5 disabled:opacity-60"
          >
            <GoogleIcon />
            <span className="text-sm">تسجيل الدخول بـ Google</span>
          </button>

          {/* Divider */}
          <div className="flex items-center gap-3 mb-5">
            <div className="flex-1 h-px bg-[#B2DFDB]" />
            <span className="text-[#90AFAC] text-xs font-semibold">أو</span>
            <div className="flex-1 h-px bg-[#B2DFDB]" />
          </div>

          {/* Tabs */}
          <div className="flex bg-[#F0FEFA] rounded-2xl p-1 mb-5">
            {(['login', 'register'] as Mode[]).map(m => (
              <button
                key={m}
                onClick={() => { setMode(m); reset(); }}
                className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${
                  mode === m ? 'bg-[#00BFA5] text-white shadow-md' : 'text-[#4A7B76]'
                }`}
              >
                {m === 'login' ? 'تسجيل الدخول' : 'حساب جديد'}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">

            {/* Username — register only */}
            {mode === 'register' && (
              <div>
                <label className="text-[#4A7B76] text-xs font-bold mb-1.5 block">اسم المستخدم *</label>
                <div className={`input-field ${username ? 'border-[#00BFA5]' : ''}`}>
                  <User size={16} className="text-[#00BFA5] ml-3" />
                  <input
                    type="text" value={username} onChange={e => setUsername(e.target.value)}
                    className="flex-1 py-3 bg-transparent outline-none text-[#0D2926] text-sm"
                    placeholder="محمد أحمد" dir="rtl"
                  />
                </div>
              </div>
            )}

            {/* Email */}
            <div>
              <label className="text-[#4A7B76] text-xs font-bold mb-1.5 block">البريد الإلكتروني *</label>
              <div className={`input-field ${email ? 'border-[#00BFA5]' : ''}`}>
                <Mail size={16} className="text-[#00BFA5] ml-3" />
                <input
                  type="email" value={email} onChange={e => setEmail(e.target.value)}
                  className="flex-1 py-3 bg-transparent outline-none text-[#0D2926] text-sm"
                  placeholder="example@email.com" dir="ltr"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="text-[#4A7B76] text-xs font-bold mb-1.5 block">كلمة المرور *</label>
              <div className={`input-field ${password ? 'border-[#00BFA5]' : ''}`}>
                <Lock size={16} className="text-[#00BFA5] ml-3" />
                <input
                  type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)}
                  className="flex-1 py-3 bg-transparent outline-none text-[#0D2926] text-sm"
                  placeholder="••••••••"
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="ml-3 text-[#90AFAC] hover:text-[#00BFA5] transition-colors">
                  {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {/* Confirm password — register only */}
            {mode === 'register' && (
              <div>
                <label className="text-[#4A7B76] text-xs font-bold mb-1.5 block">تأكيد كلمة المرور *</label>
                <div className={`input-field ${confirm ? (confirm === password ? 'border-green-400' : 'border-red-300') : ''}`}>
                  <Lock size={16} className={confirm ? (confirm === password ? 'text-green-500' : 'text-red-400') : 'text-[#00BFA5]'} style={{ marginLeft: 12 }} />
                  <input
                    type="password" value={confirm} onChange={e => setConfirm(e.target.value)}
                    className="flex-1 py-3 bg-transparent outline-none text-[#0D2926] text-sm"
                    placeholder="••••••••"
                  />
                </div>
              </div>
            )}

            {/* Error */}
            {error && (
              <div className="bg-red-50 border border-red-100 text-red-500 text-sm px-4 py-3 rounded-2xl flex items-center gap-2">
                <span className="text-base">⚠️</span> {error}
              </div>
            )}

            {/* Submit */}
            <button
              type="submit" disabled={loading}
              className="w-full py-4 bg-[#00BFA5] text-white font-black text-base rounded-2xl shadow-lg shadow-[#00BFA5]/25 disabled:opacity-60 flex items-center justify-center gap-2 transition-all hover:bg-[#009688] active:scale-[0.98]"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  جاري المعالجة...
                </span>
              ) : (
                <>
                  <LogIn size={18} />
                  {mode === 'login' ? 'دخول' : 'إنشاء الحساب'}
                </>
              )}
            </button>
          </form>

          {/* Switch mode */}
          <p className="text-center text-[#4A7B76] text-sm mt-4">
            {mode === 'login' ? (
              <>مستخدم جديد؟{' '}
                <button onClick={() => { setMode('register'); reset(); }} className="text-[#00BFA5] font-bold">
                  إنشاء حساب
                </button>
              </>
            ) : (
              <>لديك حساب؟{' '}
                <button onClick={() => { setMode('login'); reset(); }} className="text-[#00BFA5] font-bold">
                  تسجيل الدخول
                </button>
              </>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}
