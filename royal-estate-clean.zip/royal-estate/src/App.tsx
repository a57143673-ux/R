import { useState } from 'react';
import { Home, Building2, Landmark, User, BriefcaseBusiness } from 'lucide-react';
import { Property } from './data/mockData';
import TopHeader from './components/TopHeader';
import HomePage from './pages/HomePage';
import PropertiesPage from './pages/PropertiesPage';
import PropertyDetailPage from './pages/PropertyDetailPage';
import ProjectsPage from './pages/ProjectsPage';
import CompaniesPage from './pages/CompaniesPage';
import ProfilePage from './pages/ProfilePage';
import LoginPage from './pages/LoginPage';
import AdminPage from './pages/AdminPage';
import PrivacyPage from './pages/PrivacyPage';
import ContactPage from './pages/ContactPage';
import WhyUsPage from './pages/WhyUsPage';
import NotificationsPage from './pages/NotificationsPage';
import AboutPage from './pages/AboutPage';
import { unreadCount } from './pages/NotificationsPage';
import { useDarkMode } from './hooks/useDarkMode';

type Tab     = 'home' | 'properties' | 'projects' | 'companies' | 'profile';
type SubPage = 'login' | 'admin' | 'property' | 'privacy' | 'contact' | 'whyus' | 'notifications' | 'about' | null;

const NAV_ITEMS: { id: Tab; Icon: typeof Home; label: string }[] = [
  { id: 'home',        Icon: Home,              label: 'الرئيسية' },
  { id: 'properties',  Icon: BriefcaseBusiness, label: 'المنتجات' },
  { id: 'projects',    Icon: Building2,         label: 'القصص'    },
  { id: 'companies',   Icon: Landmark,          label: 'المتاجر'   },
  { id: 'profile',     Icon: User,              label: 'حسابي'     },
];

export default function App() {
  const [tab,              setTab]              = useState<Tab>('home');
  const [subPage,          setSubPage]          = useState<SubPage>(null);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [user,             setUser]             = useState<{ name: string; email: string; isAdmin: boolean } | null>(null);
  const [notifCount,       setNotifCount]       = useState(() => unreadCount());
  const { dark, toggle: toggleDark }            = useDarkMode();

  const goSub  = (p: SubPage) => setSubPage(p);
  const goBack = ()           => setSubPage(null);
  const refreshNotifs = ()    => setNotifCount(unreadCount());

  const handlePropertyClick = (p: Property) => {
    setSelectedProperty(p);
    setSubPage('property');
  };

  const handleLogin = (name: string, isAdmin: boolean) => {
    setUser({ name, email: name + '@royal.sa', isAdmin });
    setSubPage(null);
    setTab('profile');
  };

  /* ── Sub-pages ──────────────────────────────────────────── */
  if (subPage === 'login')         return <LoginPage         onLogin={handleLogin}  onBack={goBack} />;
  if (subPage === 'admin')         return <AdminPage                                 onBack={goBack} />;
  if (subPage === 'privacy')       return <PrivacyPage                               onBack={goBack} />;
  if (subPage === 'contact')       return <ContactPage                               onBack={goBack} />;
  if (subPage === 'whyus')         return <WhyUsPage                                 onBack={goBack} />;
  if (subPage === 'about')         return <AboutPage                                 onBack={goBack} />;
  if (subPage === 'notifications')
    return <NotificationsPage onBack={() => { refreshNotifs(); goBack(); }} />;
  if (subPage === 'property' && selectedProperty)
    return (
      <PropertyDetailPage
        property={selectedProperty}
        onBack={() => { setSubPage(null); setSelectedProperty(null); }}
      />
    );

  /* ── Main layout ─────────────────────────────────────────── */
  return (
    <div className={`min-h-screen max-w-lg mx-auto relative ${dark ? 'dark bg-gray-900' : 'bg-[#F0FEFA]'}`}>

      <TopHeader
        isAdmin={user?.isAdmin ?? false}
        notifCount={notifCount}
        dark={dark}
        onDarkToggle={toggleDark}
        user={user}
        activeTab={tab}
        onTabChange={(t) => setTab(t)}
        onNavigate={(page) => {
          if (page === 'admin' && user?.isAdmin) goSub('admin');
          else if (page) goSub(page as SubPage);
        }}
      />

      {/* Content — pt-14 clears the 56px fixed header */}
      <div key={tab} className="pt-14 tab-enter">
        {tab === 'home' && (
          <HomePage
            onPropertyClick={handlePropertyClick}
            onViewProperties={() => setTab('properties')}
          />
        )}
        {tab === 'properties' && <PropertiesPage onPropertyClick={handlePropertyClick} />}
        {tab === 'projects'   && <ProjectsPage />}
        {tab === 'companies'  && <CompaniesPage />}
        {tab === 'profile'    && (
          <ProfilePage
            user={user}
            onLogin={() => goSub('login')}
            onLogout={() => setUser(null)}
            onAdmin={() => goSub('admin')}
            onPrivacy={() => goSub('privacy')}
            onContact={() => goSub('contact')}
            onAbout={() => goSub('about')}
          />
        )}
      </div>

      {/* Bottom nav */}
      <nav className="nav-bottom fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-lg z-40">
        <div className="flex items-center justify-around px-1 py-2">
          {NAV_ITEMS.map(({ id, Icon, label }) => {
            const active = tab === id;
            return (
              <button
                key={id}
                onClick={() => setTab(id)}
                className="flex flex-col items-center gap-0.5 px-3 py-2 rounded-2xl transition-all min-w-0 flex-1 active:scale-95"
              >
                {active ? (
                  <span className="w-10 h-10 bg-[#00BFA5] rounded-2xl flex items-center justify-center shadow-md mb-0.5">
                    <Icon size={20} strokeWidth={2} className="text-white" />
                  </span>
                ) : (
                  <Icon size={22} strokeWidth={1.5} className="text-[#90AFAC] mb-0.5" />
                )}
                <span className={`text-[10px] font-bold leading-none ${active ? 'text-[#00897B]' : 'text-[#90AFAC]'}`}>
                  {label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
