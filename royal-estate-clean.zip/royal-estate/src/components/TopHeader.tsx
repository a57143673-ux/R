import { useState } from 'react';
import {
  Menu, X, Shield, Phone, HelpCircle, Bell, ChevronLeft,
  Home, Info, Moon, Sun, Building2, Landmark, User,
  FileText, Settings, Star, Megaphone
} from 'lucide-react';
import LogoE from './LogoE';

type Page = 'privacy' | 'contact' | 'whyus' | 'notifications' | 'admin' | 'about' | null;

interface Props {
  isAdmin?: boolean;
  notifCount?: number;
  dark?: boolean;
  onDarkToggle?: () => void;
  onNavigate: (page: Page) => void;
  onTabChange?: (tab: 'home' | 'properties' | 'projects' | 'companies' | 'profile') => void;
  activeTab?: string;
  user?: { name?: string; email: string; isAdmin: boolean } | null;
}

export default function TopHeader({
  isAdmin = false,
  notifCount = 0,
  dark = false,
  onDarkToggle,
  onNavigate,
  onTabChange,
  activeTab,
  user,
}: Props) {
  const [open, setOpen] = useState(false);

  const go    = (page: Page) => { setOpen(false); onNavigate(page); };
  const goTab = (tab: 'home' | 'properties' | 'projects' | 'companies' | 'profile') => {
    setOpen(false);
    onTabChange?.(tab);
  };

  const displayName = user?.name || user?.email?.split('@')[0] || null;
  const initials    = displayName?.charAt(0).toUpperCase() ?? null;

  return (
    <>
      {/* ── Fixed glassmorphism bar ─────────────────────── */}
      <header className="top-header fixed top-0 left-1/2 -translate-x-1/2 w-full max-w-lg z-50">
        <div className="flex items-center justify-between px-4 h-14">

          {/* Right: logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
              <LogoE size={25} color="white" weight={2.5} />
            </div>
            <span className="text-white font-black text-sm tracking-wide">رويال ستور</span>
          </div>

          {/* Left: bell + menu */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => go('notifications')}
              className="relative w-9 h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center transition-all hover:bg-white/25 active:scale-95"
            >
              <Bell size={17} className="text-white" />
              {notifCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-white text-[9px] font-black flex items-center justify-center border-2 border-transparent">
                  {notifCount > 9 ? '9+' : notifCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setOpen(true)}
              className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center transition-all hover:bg-white/25 active:scale-95"
            >
              <Menu size={18} className="text-white" />
            </button>
          </div>
        </div>
      </header>

      {/* ── Overlay ──────────────────────────────────────── */}
      <div
        className={`fixed inset-0 z-[60] bg-black/50 backdrop-blur-sm transition-opacity duration-300 ${
          open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setOpen(false)}
      />

      {/* ── Full-screen slide-in Drawer (from right / RTL) ── */}
      <div
        className={`fixed top-0 right-0 h-full w-full z-[70] transition-transform duration-300 ease-out ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
        style={{ maxWidth: '100vw' }}
      >
        <div className="drawer-glass h-full flex flex-col overflow-hidden">

          {/* ── Drawer header / user card ─────────────────── */}
          <div className="drawer-header px-5 pt-12 pb-5">
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={() => setOpen(false)}
                className="w-10 h-10 rounded-2xl bg-white/20 border border-white/20 flex items-center justify-center active:scale-95 transition-all"
              >
                <X size={20} className="text-white" />
              </button>
              <div className="flex items-center gap-3 text-right">
                <div className="w-11 h-11 rounded-2xl bg-white/15 border border-white/20 flex items-center justify-center">
                  <LogoE size={34} color="white" weight={2.2} />
                </div>
                <div>
                  <p className="text-white/50 text-[10px] mb-0.5 uppercase tracking-widest">القائمة</p>
                  <p className="text-white font-black text-lg leading-tight">رويال ستور</p>
                </div>
              </div>
            </div>

            {/* User mini-card */}
            {user ? (
              <div
                onClick={() => goTab('profile')}
                className="flex items-center gap-3 bg-white/12 border border-white/15 rounded-2xl px-4 py-3 cursor-pointer hover:bg-white/18 transition-all active:scale-[0.98]"
              >
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center font-black text-white text-base border border-white/25 flex-none">
                  {initials}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-bold text-sm truncate">{displayName}</p>
                  <p className="text-white/55 text-[11px] truncate">{user.email}</p>
                </div>
                {user.isAdmin && (
                  <span className="flex-none bg-amber-400 text-white text-[9px] font-black px-2 py-0.5 rounded-full">مدير</span>
                )}
                <ChevronLeft size={15} className="text-white/40 flex-none" />
              </div>
            ) : (
              <button
                onClick={() => goTab('profile')}
                className="w-full flex items-center gap-3 bg-white/12 border border-white/15 rounded-2xl px-4 py-3 hover:bg-white/18 transition-all active:scale-[0.98]"
              >
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center border border-white/25 flex-none">
                  <User size={18} className="text-white/70" />
                </div>
                <div className="flex-1 text-right">
                  <p className="text-white font-bold text-sm">تسجيل الدخول</p>
                  <p className="text-white/55 text-[11px]">إنشاء حساب جديد</p>
                </div>
                <ChevronLeft size={15} className="text-white/40 flex-none" />
              </button>
            )}
          </div>

          {/* ── Scrollable menu body ───────────────────────── */}
          <div className="flex-1 overflow-y-auto px-5 py-3 space-y-1 scrollbar-hide">

            {/* ── Section: الصفحات الرئيسية ── */}
            <SectionLabel label="الصفحات الرئيسية" />

            <MenuItem
              icon={Home}      label="الرئيسية"   color="#00BFA5" bg="rgba(0,191,165,0.18)"
              active={activeTab === 'home'}
              onClick={() => goTab('home')}
            />
            <MenuItem
              icon={Building2} label="المنتجات"    color="#3b82f6" bg="rgba(59,130,246,0.15)"
              active={activeTab === 'properties'}
              onClick={() => goTab('properties')}
            />
            <MenuItem
              icon={Star}      label="القصص"      color="#f59e0b" bg="rgba(245,158,11,0.15)"
              active={activeTab === 'projects'}
              onClick={() => goTab('projects')}
            />
            <MenuItem
              icon={Landmark}  label="المتاجر"    color="#8b5cf6" bg="rgba(139,92,246,0.15)"
              active={activeTab === 'companies'}
              onClick={() => goTab('companies')}
            />

            {/* ── Section: حسابي ── */}
            <SectionLabel label="حسابي" className="mt-5" />

            <MenuItem
              icon={User}         label="ملفي الشخصي"  color="#00BFA5" bg="rgba(0,191,165,0.18)"
              onClick={() => goTab('profile')}
            />
            <MenuItem
              icon={Megaphone}    label="أضف منتج"     color="#10b981" bg="rgba(16,185,129,0.15)"
              onClick={() => goTab('profile')}
            />
            <MenuItem
              icon={FileText}     label="طلباتي"       color="#6366f1" bg="rgba(99,102,241,0.15)"
              onClick={() => goTab('profile')}
            />
            <div className="relative">
              <MenuItem
              icon={Bell}       label="الدردشة والتواصل" color="#ef4444" bg="rgba(239,68,68,0.15)"
                onClick={() => go('notifications')}
              />
              {notifCount > 0 && (
                <span className="absolute top-3 left-12 w-5 h-5 bg-red-500 rounded-full text-white text-[9px] font-black flex items-center justify-center pointer-events-none">
                  {notifCount > 9 ? '9+' : notifCount}
                </span>
              )}
            </div>

            {/* ── Section: معلومات وسياسات ── */}
            <SectionLabel label="معلومات وسياسات" className="mt-5" />

            <MenuItem icon={Info}        label="عن التطبيق"       color="#3b82f6" bg="rgba(59,130,246,0.15)"  onClick={() => go('about')}   />
            <MenuItem icon={HelpCircle}  label="لماذا نحن؟"       color="#f59e0b" bg="rgba(245,158,11,0.15)"  onClick={() => go('whyus')}   />
            <MenuItem icon={Shield}      label="سياسة الخصوصية"   color="#6366f1" bg="rgba(99,102,241,0.15)"  onClick={() => go('privacy')} />
            <MenuItem icon={Phone}       label="تواصل معنا"       color="#00BFA5" bg="rgba(0,191,165,0.15)"   onClick={() => go('contact')} />

            {/* ── Section: الإدارة (admin only) ── */}
            {isAdmin && (
              <>
                <SectionLabel label="الإدارة" className="mt-5" />
                <button
                  onClick={() => go('admin')}
                  className="w-full flex items-center justify-between px-4 py-3.5 rounded-2xl bg-amber-400/15 border border-amber-300/25 hover:bg-amber-400/25 active:scale-[0.98] transition-all"
                >
                  <ChevronLeft size={16} className="text-amber-300/60" />
                  <div className="flex items-center gap-3">
                    <span className="text-amber-200 font-bold text-sm">لوحة الإدارة</span>
                    <div className="w-9 h-9 rounded-xl bg-amber-400/20 flex items-center justify-center">
                      <Settings size={17} className="text-amber-300" />
                    </div>
                  </div>
                </button>
              </>
            )}

            <div className="h-4" />
          </div>

          {/* ── Dark mode toggle ──────────────────────────── */}
          {onDarkToggle && (
            <div className="px-5 pt-3 pb-2">
              <div
                role="button"
                tabIndex={0}
                onClick={onDarkToggle}
                onKeyDown={e => e.key === 'Enter' && onDarkToggle()}
                className="w-full flex items-center justify-between px-4 py-3.5 rounded-2xl bg-white/10 border border-white/12 active:scale-[0.98] transition-all cursor-pointer"
              >
                <div className={`relative w-12 h-6 rounded-full transition-colors duration-300 ${dark ? 'bg-[#00BFA5]' : 'bg-white/30'}`}>
                  <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all duration-300 ${dark ? 'left-6' : 'left-0.5'}`} />
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-white font-bold text-sm">
                    {dark ? 'الوضع المضيء' : 'الوضع الليلي'}
                  </span>
                  <div className="w-9 h-9 rounded-xl bg-indigo-400/15 flex items-center justify-center">
                    {dark ? <Sun size={17} className="text-yellow-300" /> : <Moon size={17} className="text-indigo-300" />}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── Footer ────────────────────────────────────── */}
          <div className="px-6 pb-8 pt-2 border-t border-white/10">
            <p className="text-white/40 text-xs text-center">رويال ستور © 2025</p>
            <p className="text-white/25 text-[10px] text-center mt-0.5">جميع الحقوق محفوظة</p>
          </div>
        </div>
      </div>
    </>
  );
}

/* ── Helper sub-components ─────────────────────────────── */

function SectionLabel({ label, className = '' }: { label: string; className?: string }) {
  return (
    <p className={`text-white/45 text-[10px] font-black uppercase tracking-widest px-1 mb-2 ${className}`}>
      {label}
    </p>
  );
}

function MenuItem({
  icon: Icon, label, color, bg, onClick, active = false,
}: {
  icon: typeof Home;
  label: string;
  color: string;
  bg: string;
  onClick: () => void;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl transition-all active:scale-[0.98] ${
        active
          ? 'bg-white/20 border border-white/20'
          : 'bg-white/8 border border-white/10 hover:bg-white/15'
      }`}
    >
      <ChevronLeft size={14} className="text-white/35" />
      <div className="flex items-center gap-3">
        <span className={`text-white font-semibold text-sm ${active ? 'font-bold' : ''}`}>{label}</span>
        <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: bg }}>
          <Icon size={17} style={{ color }} />
        </div>
      </div>
    </button>
  );
}
